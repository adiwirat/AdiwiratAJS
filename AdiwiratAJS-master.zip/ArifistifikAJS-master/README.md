# ArifistifikAJS
#   Line Bot AntiJS

#   MODUL² YANG PERLU DI INSTALL

termux-setup-storage

cd storage && cd downloads

pkg install git

pkg install nano

pkg install nodejs

pkg install python -y

pkg install python2 -y

pkg install python3 -y

pkg install pip

pip install --upgrade pip

pip3 install rsa

pip3 install thrift==0.11.0

pip3 install requests

pip3 install bs4

pip3 install gtts

pip3 install beautifulsoup

pip3 install googletrans

pip3 install pafy

pip3 install humanfriendly

pip3 install goslate

pip3 install wikipedia

pip3 install youtube_dl

pip3 install tweepy

pkg update

pkg upgrade


#   Spesial Thank's To ALLAH S.W.T
#   Thank's To Arifistifik
#   Editing By Abiputrallg
